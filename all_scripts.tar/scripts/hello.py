#! /usr/bin/python3

x = 10
print("Hello World!!!")
print(x)
