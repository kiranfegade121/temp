#! /bin/bash

function display()
{
   echo "Script Name: " $0
   echo "Total no. of arguments: " $#
   echo "All arguments: "$@
   echo "First argument: " $1
   echo "Second argument: " $2
}

display 10 20 

