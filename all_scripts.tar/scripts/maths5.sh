   #! /bin/bash

   read -p "Enter value of a: " a
   read -p "Enter value of b: " b
   
   sum=$[a+b]
   echo "Total: $sum"

