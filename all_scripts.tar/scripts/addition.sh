#! /bin/bash

function total() 
{
   if [ $# -ne 2 ]
   then
      echo "Please provide exactly 2 arguments"
      return 1
   else
      echo "Total: $(($1+$2))"
   fi
}
total 10 20
echo "Return value of function: $?"
total 10
echo "Return value of function: $?"

