#! /bin/bash
source ./util.sh

addition 10 20
subtraction 30 10
multiplication 5 6
division 10 2
echo "value of a: $a"
echo "value of b: $b"

