#! /bin/bash

# Demo program where use will enter file name and script will display content of file.

functionDisplayInputBox() {
  filename=$(dialog --inputbox "Enter filename: " 10 20 3>&1 1>&2 2>&3 3>&-)
}

functionDisplayInputBox
if [ -f $filename ]; then
   cat $filename
else
   echo "nothing to print" 
fi

