#! /bin/bash

for name in $(cat employee_names.txt)
do 
   useradd $name 
   passwd $name
   echo "------------------"
done
