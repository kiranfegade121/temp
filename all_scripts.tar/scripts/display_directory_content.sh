#! /bin/bash

function display() 
{
   ls $1
}

read -p "Please entr a directory: " dir
display $dir

