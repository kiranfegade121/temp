#! /bin/bash

name="amitf"
action="sleep"
echo "Name: $name"
echo "I like $actioning"
echo "I like ${action}ing"

