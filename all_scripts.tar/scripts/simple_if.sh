#! /bin/bash

echo "Start"
if [ $USER = "root" ]
then
   echo "Welcome: $USER"
fi
echo "End"
