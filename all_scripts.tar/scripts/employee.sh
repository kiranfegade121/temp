  #! /bin/bash
  
  read -p "Please enter employee id: " id
  read -p "Please enter employee name: " name
  read -p "Please enter employee department: " dept
  read -p "Please enter employee salary: " salary
  read -p "Please enter employee designation: " desg

  echo "$id, $name, $dept, $salary, $desg" > employee.txt  
  echo "Employee record has been added successfully"

