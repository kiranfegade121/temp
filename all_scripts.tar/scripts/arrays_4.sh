#! /bin/bash

read -p "How many elements inside an arrays: " n

for((i=0;i<n;i++))
do
  read -p "Enter a value: " arr[i]
done

echo "All array elements: ${arr[@]}"
unset arr[0]
unset arr[1]
echo "After removing first and second elements, array: ${arr[@]}"
