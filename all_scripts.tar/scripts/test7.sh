#! /bin/bash

echo -n "Enter value of a: "
read a

echo -n "Enter value of b: "
read b

echo "Value of a and b: $a $b"

