#! /bin/bash

read -p "Please enter username: " username
read -s -p "Please enter password: " password
echo
echo  "Thanks $username"

