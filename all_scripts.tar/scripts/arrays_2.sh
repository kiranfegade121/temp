#! /bin/bash

courses[0]="Java"
courses[1]="Python"
courses[2]="DevOps"
courses[10]="Django"
courses[20]="PHP"

echo "First course: ${courses[0]}"
echo "Second course: ${courses[1]}"
echo "Course at index 4: ${courses[4]}"
echo "All courses: ${courses[@]}"
echo "Total no. of courses: ${#courses[@]}"
echo "Index values: ${!courses[@]}"

