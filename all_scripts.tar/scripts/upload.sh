#! /bin/bash

fname="imp.txt"
while [ ! -e $fname ]
do 
  sleep 2
done
echo "$fname is now available... uploading a file..."

