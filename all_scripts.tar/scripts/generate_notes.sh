#! /bin/bash

DOCFILE="final_notes.txt"
files=($(ls *.sh))

for file in ${files[@]}; do
   if [ -f $file ]; then
      echo "=======================================" >> ${DOCFILE}
      echo "SCRIPT NAME: $file" >> ${DOCFILE}
      echo "=======================================" >> ${DOCFILE}
      echo "" >> ${DOCFILE}   
      echo "`cat $file`" >> ${DOCFILE}
   fi
done
  
       
