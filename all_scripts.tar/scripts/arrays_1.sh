#! /bin/bash

courses=(Java Python Django PHP DevOps)

echo "First course: ${courses[0]}"
echo "Second course: ${courses[1]}"
echo "All courses: ${courses[@]}"
echo "Total no. of courses: ${#courses[@]}"
echo "Index values: ${!courses[@]}" 

