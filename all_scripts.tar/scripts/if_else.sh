#! /bin/bash

if [ $# -ne 2 ]
then 
   echo "You should provide exactly 2 arguments"
   exit 1
fi

x=$1
y=$2
sum=`expr $x + $y`
if [ $? -ne 0 ]
then 
  echo "You should provide only integer values"
  exit 2
else
  echo "Total: $sum"
fi
