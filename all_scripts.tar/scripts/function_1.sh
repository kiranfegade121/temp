#! /bin/bash

function greet() 
{
  echo "Good Morning"
}

greet2() 
{
   echo "Good Night" 
}

greet
greet2


