#!/bin/bash

echo "Change to a directory and removig entire content: "
DIRECTORY=$1

cd ${DIRECTORY}>/dev/null
if [ $? = 0 ]; then
  echo "deleting a content: "
  # rm -rf *
else
 echo "failed to delete a content"
fi
