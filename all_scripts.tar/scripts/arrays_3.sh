#! /bin/bash

files=($(ls $1))

#echo "All filenames: ${files[@]}" 
#echo "Total no. of files: ${#files[@]}"

for file in ${files[@]}
do 
  echo -ne "$file:   "
  if [ -r $file ]
  then 
    echo -ne "READ[Y]   "
  else
    echo -ne "READ[N]   "
  fi
  if [ -w $file ]
  then
    echo -ne "WRITE[Y]   " 
  else
    echo -ne "WRITE[N]   "
  fi
  if [ -x $file ]
  then
     echo -ne "EXECUTE[Y]   "
  else
     echo "EXECUTE[N]   "
  fi
  echo 
done


