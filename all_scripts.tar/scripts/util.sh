#! /bin/bash

a=888
b=999

function addition()
{
  echo "$1 + $2 = $[$1+$2]"
}

function subtraction()
{
   echo "$1 - $2 = $[$1-$2]"
}

function multiplication()
{
   echo "$1 * $2 = $[$1*$2]"
}

function division()
{
   echo "$1 / $2 = $[$1/$2]"
}


