#! /bin/bash

read -p "Please enter filename: " fname
if [ -e $fname ]
then 
    echo "$fname exists"
else
    echo "$fname doesn't exists"
fi

