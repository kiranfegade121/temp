#! /bin/bash

read -p "Enter a filename: " fname

READ="NO"
WRITE="NO"
EXECUTE="NO"

if [ -r $fname ]
then 
    READ="YES"
fi

if [ -w $fname ]
then 
    WRITE="YES"
fi

if [ -x $fname ]
then 
   EXECUTE="YES"
fi

echo "User permissions:"
echo "-------------------"
echo "Read permission: $READ"
echo "Write permission: $WRITE"
echo "Execute permission: $EXECUTE"







