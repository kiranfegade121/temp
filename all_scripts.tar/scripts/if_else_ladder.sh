#! /bin/bash

read -p "Enter a filename: " fname

if [ -L $fname ]
then 
    echo "$fname is symbolic link"
elif [ -f $fname ]
then 
    echo "$fname is regular file"
elif [ -d $fname ]
then 
    echo "$fname is directory"
else
    echo "This is something special file"
fi
  
