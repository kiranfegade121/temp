#! /bin/bash

while [ true ]
do 
    read -p "Please enter a filename: " fname
    if [ ! -e $fname ]
    then 
       echo "$fname doesn't exists"
       exit 1
    elif [ -f $fname ]
    then
       echo "The content of file"
       echo "-------------------"
       cat $fname
    else
       echo "Please provide regular file"
       exit 2
    fi
   
    read -p "Would you like to continue: [Y/N]: " ch
    case $ch in
    "Y") 
       continue
       ;;
    "N")
       break
       ;;
    esac
done
echo "End of script"
 
        
 
