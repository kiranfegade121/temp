#! /bin/bash

function func1() 
{
   echo "Inside function1"
}
function func2() 
{
   echo "Inside function2"
   func1
}
func2



