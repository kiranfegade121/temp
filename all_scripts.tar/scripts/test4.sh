#! /bin/bash

len=$(echo -n $1 | wc -c)
echo "The total no. of characters: $len"
