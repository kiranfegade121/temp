#! /bin/bash
echo "Hello World!!!"
date
cal
