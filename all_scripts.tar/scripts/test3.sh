#! /bin/bash

str="This is a sample statement"
len=$(echo -n $str | wc -c)
echo "The length of the string: $len"

