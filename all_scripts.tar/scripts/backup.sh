#! /bin/bash

function backup()
{
   tar -cvzf /imp/backup_$(date +%d_%m_%Y_%H_%M_%S).tar $1     
}

read -p "Please enter directory path whose backup you want to take: " dir
backup $dir
