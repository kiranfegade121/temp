#! /bin/bash

for fname in *
do
  if [ -f $fname ]
  then
     echo $fname
  fi
done
