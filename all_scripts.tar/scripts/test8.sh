#! /bin/bash

read -p "Enter value of a: " a
read -p "Enter value of b: " b
echo "The value of a and b: $a $b"

