#! /bin/bash

function display()
{
   x=20
   echo "value of x: $x"
}
x=10
display
echo "After display function: value of x: $x"

