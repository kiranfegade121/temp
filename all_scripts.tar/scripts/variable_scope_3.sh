#! /bin/bash

function display()
{
  echo "value of a: $a"
}

display
a=10
display

