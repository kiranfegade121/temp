#! /bin/bash

read -p "Enter first number: " a
read -p "Enter second number: " b

sum=$(echo $a+$b | bc)
echo "Total: $sum"
echo "Difference: " $(echo $a-$b | bc)
echo "Multiplication: " $(echo $a*$b | bc)

