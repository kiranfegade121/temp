#! /bin/bash

exec 3>&1 1>>$0.log_$(date "+%h-%d-%Y-%H-%M") 2>&1
echo "Hello"

