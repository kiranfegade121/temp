#! /bin/bash

function display()
{
   echo "value of x: $x"
}

x=10
display

