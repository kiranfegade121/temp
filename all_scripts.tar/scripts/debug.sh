#!/bin/bash

echo "Username: " $USER
echo "Home directory: "$HOME
set -x
echo "Path variabloe: " $PATH
set +x
