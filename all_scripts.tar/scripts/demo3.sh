#! /bin/bash
echo "Username: $USER"
echo "User home directory: $HOME"
echo "Default shell: $SHELL"
echo "PATH: $PATH"
