#! /bin/bash

awk -f emp.awk emp.lst
