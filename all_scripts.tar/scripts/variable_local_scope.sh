#! /bin/bash

function display()
{
   local b=10
   echo "value of b: $b"
}
display
echo "value of b from outside of display function: $b"
